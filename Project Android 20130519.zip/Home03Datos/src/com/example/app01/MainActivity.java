package com.example.app01;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

	/*** VARIABLES **/
	ConDataBase data_base;
	String TAG = "MainActivity.java";
			
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent servicio = new Intent(this, SerBackGround_WebSer.class);
		startService(servicio);		
		setContentView(R.layout.activity_main);
		data_base = new ConDataBase(this);
		Log.d(TAG, "onCreate");
	}


	/** methods functional **/
	public void click_button01(View V){
		Log.d(TAG, "button clickeado");
		String alumno = ((TextView) findViewById(R.id.ET_alumno)).getText().toString();
		String nota = ((TextView) findViewById(R.id.ET_nota)).getText().toString();
		try{
			data_base.insertar(alumno, nota);
		}catch(Exception e){
			Log.e(TAG, "insert data base", e);
		}		
	}
	
}
