package com.example.app01;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class bootBroCasRec extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		Intent servicio = new Intent();
		servicio.setAction("com.example.app01.SerBackGround_WebSer");
		context.startService(servicio);
	}

}
