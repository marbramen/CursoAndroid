package com.example.app01;

import java.util.ArrayList;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;

import android.util.Log; 


public class ConDataBase extends SQLiteOpenHelper{

	/** variables others **/
	private static String TAG = "ConDataBase.java";		
	
	/** variables database **/ 
	private static String NameDataBase = "CursoAndroid";
	private static String Table = "NotasAlumnos";
	private static int Version = 1;	
	/** name columns **/
	private static String COL_ID = "ID";
	private static String COL_Alumno = "alumno";
	private static String COL_Nota = "nota";
	private static String COL_DatHou = "dateHour";
	private static String COL_StaSen = "statusSend";
	
	/** sentences SQLite **/
	private static String DB_create = "CREATE TABLE " + Table + " ( " 
			+ COL_ID + " Integer PRIMARY KEY AUTOINCREMENT," 
			+ COL_Alumno + " TEXT,"
			+ COL_Nota + " TEXT,"
			+ COL_DatHou + " TEXT,"
			+ COL_StaSen + " TEXT )"; 
	private static String DB_upgrade = "DROP TABLE IF EXIST " + NameDataBase + "." +Table;
	private static String DB_selectNotSend = "SELECT " +
			COL_ID + " , " +
			COL_Alumno + ", " + 
			COL_Nota +
			" FROM " + Table +
			" WHERE " + COL_StaSen + "= '0';";
	  	
	
	
	/*** methods sqlite Open Helper***/
	public ConDataBase(Context contexto){
		super(contexto, NameDataBase, null, Version);
		Log.d(TAG, "constructor");
	}
		
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL(DB_create);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		db.execSQL(DB_upgrade);
	}
	
	/*** methods database **/
	public void insertar(String GluInd, String BloPre){	
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues newRegister = new ContentValues();		
		newRegister.put(COL_Alumno, GluInd);
		newRegister.put(COL_Nota, BloPre);
		newRegister.put(COL_DatHou, getHourAtual());
		newRegister.put(COL_StaSen, "0"); // not send server		
		try{			
			db.insert(Table, null, newRegister);
		}catch(Exception  e){
			Log.e(TAG, "error al insertar", e);
		}finally{
			db.close();
		}				
	}
		
	// chose row->StateSend not sent
	public ArrayList<Data> dataNotSend(){
		SQLiteDatabase db = this.getReadableDatabase();
		ArrayList<Data> result = new ArrayList<Data>();
		try{
			Cursor response_sente = db.rawQuery(DB_selectNotSend, null);
			// each two => new register
			while(response_sente.moveToNext()){
				Data one_row = new Data();
				one_row.setID(response_sente.getString(0));
				one_row.setAlumno(response_sente.getString(1));
				one_row.setNota(response_sente.getString(2));
				result.add(one_row);
			}						
		}catch(Exception e ){
			Log.e(TAG, "error en el data send", e);
		}		
		return result; 
	}
	
	public void UpdateState(String ID){
		SQLiteDatabase db = this.getWritableDatabase(); 	
		ContentValues columns = new ContentValues();
		columns.put(COL_StaSen, "1");
		if(1 == db.update(Table, columns, COL_ID + " = ?", new String[]{ID}) )
			Log.d(TAG, "ya ta seteado");
		
	}
	
	
	/** methods add **/
	private String getHourAtual(){
		//format YYYY-MM-DD hh:mm:ss
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);		
	}	
		
}
