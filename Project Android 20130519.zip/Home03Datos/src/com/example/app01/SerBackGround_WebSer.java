package com.example.app01;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class SerBackGround_WebSer extends Service {
	
	/** Variables DataBase**/
	ConDataBase dataBase ; 
	
	/** Variables SOAP **/
	private static String SOAP_ACTION = "http://localhost/CursoAndroidUnsa";
	private static String NAMESPACE = "http://localhost/";
	private static String METHOD_NAME = "EnviarNotasCursoAndroid";
	private static String PARA_Alumno = "alumno";
	private static String PARA_Nota = "nota";
	// el web services no esta en el mismo dispositivo	
	private static String URL = "http://10.0.2.2:49734/Service1.asmx?WSDL";
	
	private static SoapObject request, result_xml;
	private static SoapSerializationEnvelope envelope; 
	private static HttpTransportSE androidTransport; 
	
	/** Variables OTHER */
	private static String TAG = "SerBackGround_WebSer.java";
	private static Timer timer ; 
	private static long updateTime = 10000; // each ten second
	private static ArrayList<Data> notSent;
	
	Context cont ;
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// TODO Auto-generated method stub
		Toast.makeText(this, "Servicio en Ejecucion", Toast.LENGTH_SHORT).show();
		cont = this; 
		Log.d(TAG, "servicio lanzado");
		return super.onStartCommand(intent, flags, startId);
		
	}

	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {	
		super.onCreate();
		// TODO Auto-generated method stub
		Log.d(TAG, "services onCreate()");
		
		timer = new Timer();
		dataBase = new ConDataBase(this);
		sendToServer();		
	}
	
	public void sendToServer(){
		timer.scheduleAtFixedRate(new TimerTask() {			
			@Override
			public void run() {
				//obtain values not sent
				notSent = dataBase.dataNotSend(); 
				// Consume web services
				for(int i = 0 ; i < notSent.size() ; i++){				
					request = new SoapObject(NAMESPACE, METHOD_NAME);		
					request.addProperty(PARA_Alumno, notSent.get(i).getAlumno());
					request.addProperty(PARA_Nota, notSent.get(i).getNota());
					envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
					envelope.setOutputSoapObject(request);
					envelope.dotNet = true; 					
					try{
						androidTransport = new HttpTransportSE(URL);
						androidTransport.debug = true;
						androidTransport.call(SOAP_ACTION, envelope);
						result_xml = (SoapObject) envelope.bodyIn;
						Log.d(TAG, "respuesta del server " + androidTransport.responseDump); 
						//
						if(result_xml != null){
							Log.d(TAG,"actualizando datos" + notSent.get(i).getID() + result_xml.getProperty(0).toString());
							Toast.makeText(cont, "dato recibido en la centrarl", Toast.LENGTH_SHORT); 
							if(result_xml.getProperty(0).toString().equals("1"))
								dataBase.UpdateState(notSent.get(i).getID());
						}
						else
							Log.d(TAG, result_xml.getProperty(0).toString()+ " "+notSent.get(i).getID());
							Toast.makeText(cont, "dato no recibido en la centrarl", Toast.LENGTH_SHORT); 
						//Log.d(TAG, "insertando en el web services");
					}catch(Exception e){
						Log.e(TAG, "problema con la conexion nueva", e);
						Toast.makeText(cont, "error", Toast.LENGTH_SHORT);
					}
					
				}
				Log.d(TAG, "   espacio ");
			}
		}, 0, updateTime);
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}	
	
}
